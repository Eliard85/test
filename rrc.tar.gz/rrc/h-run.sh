#!/usr/bin/env bash

cd `dirname $0`

[ -t 1 ] && . colors

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
. $SCRIPT_DIR/h-manifest.conf

[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}" && exit 1

#echo -e "${GREEN}> Starting $CUSTOM_MINERBIN${NOCOLOR}"
#echo -e "${GREEN}> ./$CUSTOM_MINERBIN $(< $CUSTOM_CONFIG_FILENAME)${NOCOLOR}"

$LINE
echo -e "${GREEN}> Starting custom miner:${WHITE}"
MY_PID=$$
screenName="rrc"
batch="./$CUSTOM_NAME $(< $CUSTOM_CONFIG_FILENAME)"

$SCRIPT_DIR/screen-kill $screenName
screen -dmS "$screenName" bash -c "$batch"

tail -f /dev/null
