#!/usr/bin/env bash

cd `dirname $0`

[ -t 1 ] && . colors

. h-manifest.conf

echo $CUSTOM_NAME
echo $CUSTOM_LOG_BASENAME
echo $CUSTOM_CONFIG_FILENAME

[[ -z $CUSTOM_LOG_BASENAME ]] && echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}" && exit 1
[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}" && exit 1

nconfig_line=$(cat config.conf 2>/dev/null)

if [[ -n "$nconfig_line" ]]; then
    set -- $nconfig_line

    while [[ $# -gt 0 ]]; do
        case $1 in
            --pool)
                NPOOL="$2"
                shift 2
                ;;
            --wallet)
                NWALLET="$2"
                shift 2
                ;;
            --worker)
                NWORKER_NAME="$2"
                shift 2
                ;;
            *)
                shift
                ;;
        esac
    done
fi

cat > config.json <<EOF
{
  "selected": ["npt-gpu"],
  "algo_list": [
    {
      "id": "npt-gpu",
      "algo": "neptune",
      "pool": "$NPOOL",
      "worker_name": "$NWORKER_NAME",
      "address": "$NWALLET",
      "config": {
        "type": "gpu",
        "option": "all"
      }
    }
  ]
}
EOF

./$MINER_NAME run --config ./config.json $@ 2>&1 | tee $CUSTOM_LOG_BASENAME.log
