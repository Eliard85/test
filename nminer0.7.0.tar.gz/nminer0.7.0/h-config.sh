#!/usr/bin/env bash
[[ -e /hive/custom ]] && . /hive/custom/$CUSTOM_NAME/h-manifest.conf
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/$CUSTOM_NAME/h-manifest.conf
conf=""
conf+="--pool $CUSTOM_URL --wallet $CUSTOM_TEMPLATE --worker $WORKER_NAME"

echo "$conf"
echo "$conf" > $CUSTOM_CONFIG_FILENAME
