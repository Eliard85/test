#!/usr/bin/env bash

mkfile_from_symlink $CUSTOM_CONFIG_FILENAME

user_config="-N $CUSTOM_URL -m $CUSTOM_TEMPLATE $CUSTOM_USER_CONFIG"

#generating config
echo "$user_config" > $CUSTOM_CONFIG_FILENAME
