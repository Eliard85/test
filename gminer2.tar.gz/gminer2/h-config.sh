#!/usr/bin/env bash

echo "WORKER_NAME =             $WORKER_NAME"
echo "CUSTOM_TEMPLATE =         $CUSTOM_TEMPLATE"
echo "CUSTOM_URL =              $CUSTOM_URL"
echo "CUSTOM_PASS =             $CUSTOM_PASS"
# echo "CUSTOM_ALGO =           $CUSTOM_ALGO"
echo "CUSTOM_USER_CONFIG =      $CUSTOM_USER_CONFIG"
echo "CUSTOM_CONFIG_FILENAME =  $CUSTOM_CONFIG_FILENAME"

[[ -e /hive/miners/custom ]] && . /hive/miners/custom/$CUSTOM_NAME/h-manifest.conf

pubkey="${CUSTOM_TEMPLATE%%.*}"
name="${CUSTOM_TEMPLATE#*.}"

conf=
conf+="--pubkey $pubkey"
conf+=" --name $name"

echo "$conf" > $CUSTOM_CONFIG_FILENAME
echo "$CUSTOM_USER_CONFIG" > $CUSTOM_USER_CONFIG_FILENAME

