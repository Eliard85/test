#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

[ -t 1 ] && . colors || true
. h-manifest.conf

[[ -z ${CUSTOM_LOG_BASENAME:-} ]] && echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}" && exit 1
[[ -z ${CUSTOM_CONFIG_FILENAME:-} ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f "$CUSTOM_CONFIG_FILENAME" ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}" && exit 1
[[ ! -f ${CUSTOM_MINERBIN:-} ]] && echo -e "${RED}Miner binary ${YELLOW}$CUSTOM_MINERBIN${RED} is not found${NOCOLOR}" && exit 1

CUSTOM_LOG_BASEDIR="$(dirname "$CUSTOM_LOG_BASENAME")"
[[ ! -d "$CUSTOM_LOG_BASEDIR" ]] && mkdir -p "$CUSTOM_LOG_BASEDIR"

echo "Starting miner with config: $(< "$CUSTOM_CONFIG_FILENAME")"

# Доп.аргументы (могут отсутствовать)
ARGS=""
[[ -f addition.conf ]] && ARGS="$(tr -d '\n' < "addition.conf")"

# --- ПАРСИНГ КЛЮЧЕЙ (-t и -ex_gpu), поддержка форм: -t 5 / -t=5 ; -ex_gpu 3,4 / -ex_gpu=3,4
T="$(echo "$ARGS" | grep -oP '(?<=-t[=\s])\S+' 2>/dev/null || true)"
EX_GPU_RAW="$(echo "$ARGS" | grep -oP '(?<=-ex_gpu[=\s])[0-9,]+' 2>/dev/null || true)"

# --- Список всех GPU (nvidia). Фолбэк через GPU_STATS_JSON, если nvidia-smi не доступен.
if ! ALL_GPUS="$(nvidia-smi --query-gpu=index --format=csv,noheader 2>/dev/null | paste -sd "," -)"; then
  echo -e "${YELLOW}nvidia-smi not found or failed. Falling back to 0..N-1 based on GPU_STATS_JSON.${NOCOLOR}"
  if [[ -f "${GPU_STATS_JSON:-}" ]]; then
    NUM="$(jq -r '.busids | length' "$GPU_STATS_JSON" 2>/dev/null || echo 0)"
    if [[ "$NUM" -gt 0 ]]; then
      ALL_GPUS=$(seq -s, 0 $((NUM-1)))
    else
      echo -e "${RED}Cannot determine GPU list.${NOCOLOR}"; exit 1
    fi
  else
    echo -e "${RED}GPU_STATS_JSON is missing and nvidia-smi failed.${NOCOLOR}"; exit 1
  fi
fi

IFS=',' read -r -a ALL_ARRAY <<< "$ALL_GPUS"
IFS=',' read -r -a EXCLUDE_ARRAY <<< "${EX_GPU_RAW:-}"

VISIBLE_GPUS=()
for gpu in "${ALL_ARRAY[@]}"; do
  skip=false
  for ex in "${EXCLUDE_ARRAY[@]}"; do
    [[ -n "$ex" && "$gpu" == "$ex" ]] && skip=true && break
  done
  $skip || VISIBLE_GPUS+=("$gpu")
done

if [[ "${#VISIBLE_GPUS[@]}" -eq 0 ]]; then
  echo -e "${RED}No GPUs left after applying -ex_gpu${NOCOLOR}"; exit 1
fi

VISIBLE_GPUS_STR="$(IFS=','; echo "${VISIBLE_GPUS[*]}")"

# Сохраняем порядок CUDA->Hive для stats.sh
echo "$VISIBLE_GPUS_STR" > "${CUSTOM_LOG_BASENAME}.cuda_order"

# Отладочная информация
echo "ALL_GPUS:        $ALL_GPUS"
echo "EX_GPU:          ${EX_GPU_RAW:-<none>}"
echo "VISIBLE_GPUS:    $VISIBLE_GPUS_STR"
[[ -n "${T:-}" ]] && echo "Threads-per-card: $T" || echo "Threads-per-card: <not set>"

# Собираем команду запуска
EXTRA_ARGS=()
# передаём --threads-per-card= только если T найден
[[ -n "${T:-}" ]] && EXTRA_ARGS+=( "--threads-per-card=$T" )

# Запуск майнера с правильным CUDA_VISIBLE_DEVICES
# ВАЖНО: не кавычить подстановку конфиг-файла, чтобы он распался по аргументам корректно.
CUDA_VISIBLE_DEVICES="$VISIBLE_GPUS_STR" \
  "./$CUSTOM_MINERBIN" $(< "$CUSTOM_CONFIG_FILENAME") "${EXTRA_ARGS[@]}" "$@" \
  2>&1 | tee "$CUSTOM_LOG_BASENAME.log"

