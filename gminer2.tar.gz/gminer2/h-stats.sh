#!/usr/bin/env bash
# stats.sh — генерация статистики HiveOS с учётом CUDA_VISIBLE_DEVICES (.cuda_order)
# и логов формата: ".... INFO Card-3 speed:  5.96 p/s"

# Не включаем set -e/-u/-o pipefail, чтобы не падать на "нет совпадений" и пр.

. /hive/miners/custom/gminer2/h-manifest.conf

algo=BLAKE3
maxDelay=120

time_now=$(date '+%s')
time_log=$(stat -c %Y "$CUSTOM_LOG_BASENAME.log" 2>/dev/null || echo 0)

# Базовые проверки лога
if [[ ! -f "$CUSTOM_LOG_BASENAME.log" ]]; then
  time_log=0
else
  log_size=$(wc -l < "$CUSTOM_LOG_BASENAME.log" 2>/dev/null || echo 0)
  [[ $log_size -lt 5 ]] && time_log=0
fi

# Если в последних строках есть явные ошибки — инвалидируем
tail -n 20 "$CUSTOM_LOG_BASENAME.log" 2>/dev/null | grep -qiE "Disconnected|error|failed|timeout" && time_log=0

if (( time_now < time_log + maxDelay )); then
  # Активность (грубо)
  ac=$(grep -cE "New task received|Heartbeat success" "$CUSTOM_LOG_BASENAME.log" 2>/dev/null || echo 0)
  rj=0

  # Телеметрия GPU из Hive
  if [[ -f "${GPU_STATS_JSON:-}" ]]; then
    mapfile -t busids < <(jq -r '.busids[]' "$GPU_STATS_JSON" 2>/dev/null)
    mapfile -t brands < <(jq -r '.brand[]'  "$GPU_STATS_JSON" 2>/dev/null)
    mapfile -t temps  < <(jq -r '.temp[]'   "$GPU_STATS_JSON" 2>/dev/null)
    mapfile -t fans   < <(jq -r '.fan[]'    "$GPU_STATS_JSON" 2>/dev/null)
  else
    echo "null"
    exit 0
  fi

  # -------------------------------
  # Порядок CUDA -> Hive (Card-pos -> hive_idx)
  # -------------------------------
  order_hive_indices=()
  if [[ -f "$CUSTOM_LOG_BASENAME.cuda_order" ]]; then
    # Файл содержит CSV Hive-индексов в порядке, как майнер видит Card-0..N
    mapfile -t order_hive_indices < <(tr -d '\n' < "$CUSTOM_LOG_BASENAME.cuda_order" | tr ',' '\n' | awk 'NF{print}')
  else
    # Фолбэк: уберём -ex_gpu из CUSTOM_USER_CONFIG_FILENAME
    exclude_str=$(echo "${CUSTOM_USER_CONFIG_FILENAME:-}" | grep -oE '\-ex_gpu[=\s][0-9,]+' | sed -E 's/.*[=\s]//' 2>/dev/null)
    IFS=',' read -r -a exclude_gpus <<< "${exclude_str:-}"
    is_excluded() {
      local idx="$1"
      for ex in "${exclude_gpus[@]:-}"; do
        [[ -n "$ex" && "$idx" == "$ex" ]] && return 0
      done
      return 1
    }
    for ((i=0; i<${#busids[@]}; i++)); do
      is_excluded "$i" || order_hive_indices+=("$i")
    done
  fi

  if [[ ${#order_hive_indices[@]} -eq 0 ]]; then
    echo "null"
    exit 0
  fi

  # -------------------------------
  # Парсим скорости из лога
  # Соберём последние встреченные значения Card-<N> speed: <val> p/s
  # -------------------------------
  declare -A card_speeds

  # Возьмём последние 1000 строк, отфильтруем по "Card-<число> speed:", чтобы не гонять весь лог
  # Парсим через bash-режех, чтобы быть максимально гибкими к форматированию
  while IFS= read -r line; do
    # Разрешаем любые префиксы (таймстамп/INFO), произвольные пробелы
    if [[ "$line" =~ Card-([0-9]+)[[:space:]]+speed:[[:space:]]*([0-9]+([.][0-9]+)?) ]]; then
      cuda_idx="${BASH_REMATCH[1]}"
      speed="${BASH_REMATCH[2]}"
      # записываем "последнее" значение — оно будет референтным
      card_speeds["$cuda_idx"]="$speed"
    fi
  done < <(tail -n 1000 "$CUSTOM_LOG_BASENAME.log" 2>/dev/null | grep -E 'Card-[0-9]+[[:space:]]+speed:' || true)

  # -------------------------------
  # Формируем массивы статистики
  # -------------------------------
  hash_arr=()
  busid_arr=()
  temp_arr=()
  fan_arr=()
  total_hashrate="0"

  for ((pos=0; pos<${#order_hive_indices[@]}; pos++)); do
    hive_idx="${order_hive_indices[$pos]}"

    # Защита от выхода за границы
    [[ "$hive_idx" =~ ^[0-9]+$ ]] || continue
    (( hive_idx < ${#brands[@]} )) || continue

    brand="${brands[$hive_idx]}"
    [[ "$brand" != "nvidia" && "$brand" != "amd" ]] && continue

    busid="${busids[$hive_idx]}"
    temp="${temps[$hive_idx]}"
    fan="${fans[$hive_idx]}"

    # Преобразуем BUSID к десятичному номеру шины для Hive
    if [[ "$busid" =~ ^([A-Fa-f0-9]+): ]]; then
      busid_decimal=$((16#${BASH_REMATCH[1]}))
    else
      busid_decimal=0
    fi

    # Скорость по позиции CUDA (Card-pos)
    hash="0"
    if [[ -n "${card_speeds[$pos]:-}" ]]; then
      hash="${card_speeds[$pos]}"
    fi

    hash_arr+=("$hash")
    busid_arr+=("$busid_decimal")
    temp_arr+=("$temp")
    fan_arr+=("$fan")

    # Сумма (числовая)
    total_hashrate=$(awk -v a="$total_hashrate" -v b="$hash" 'BEGIN{printf("%.6f", a + b)}')
  done

  # -------------------------------
  # Готовим JSON
  # -------------------------------
  # Все массивы делаем числовыми (jq читает каждый элемент как JSON-значение)
  hash_json=$(printf '%s\n' "${hash_arr[@]}" | jq -cs '.')
  bus_numbers=$(printf '%s\n' "${busid_arr[@]}" | jq -cs '.')
  fan_json=$(printf '%s\n' "${fan_arr[@]}" | jq -cs '.')
  temp_json=$(printf '%s\n' "${temp_arr[@]}" | jq -cs '.')

  uptime_src=$(stat -c %Y "$CUSTOM_CONFIG_FILENAME" 2>/dev/null || echo "$time_now")
  uptime=$(( time_now - uptime_src ))
  [[ $uptime -lt 0 ]] && uptime=0
  version="${CUSTOM_VERSION:-unknown}"

  stats=$(jq -nc \
    --argjson hs "$hash_json" \
    --arg ver "$version" \
    --arg algo "$algo" \
    --argjson bus_numbers "$bus_numbers" \
    --argjson fan "$fan_json" \
    --argjson temp "$temp_json" \
    --arg ac "$ac" --arg rj "$rj" \
    --arg uptime "$uptime" \
    '{ $hs, hs_units: "p/s", $algo, $ver, $uptime, $bus_numbers, $temp, $fan, ar: [$ac|tonumber, $rj|tonumber] }')

  khs="$total_hashrate"
else
  khs=0
  stats="null"
fi

[[ -z "${khs:-}" ]] && khs=0
[[ -z "${stats:-}" ]] && stats="null"

echo "$stats"

