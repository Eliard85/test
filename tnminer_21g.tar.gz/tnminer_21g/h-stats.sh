#!/usr/bin/env bash

#echo $stats
#echo $khs
#echo $temp
#echo $fan
