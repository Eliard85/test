#!/usr/bin/env bash

cd `dirname $0`

[ -t 1 ] && . colors

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
. $SCRIPT_DIR/h-manifest.conf
echo "> install dependencies"
$SCRIPT_DIR/install.sh
echo "> dependencies installed"

[[ -z $CUSTOM_LOG_BASENAME ]] && echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}" && exit 1
[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}" && exit 1

#echo -e "${GREEN}> Starting $CUSTOM_MINERBIN${NOCOLOR}"
#echo -e "${GREEN}> ./$CUSTOM_MINERBIN $(< $CUSTOM_CONFIG_FILENAME)${NOCOLOR}"

#./$CUSTOM_MINERBIN $(< $CUSTOM_CONFIG_FILENAME) $@ 2>&1 | tee $CUSTOM_LOG_BASENAME.log

$LINE
echo -e "${GREEN}> Starting custom miner:${WHITE}"
MY_PID=$$
t=$(( $(nproc --ignore=1) / 3 ))
for ((i = 1; i <= t; i++)); do
  screenName="java$i"
  log="/var/log/java$i.log"
  batch="java -jar -Xmx8G ./cpu.jar $(< $CUSTOM_CONFIG_FILENAME) -t 3 -P 5001"
  fullBatch=$(cat <<EOF
(
  ( while kill -0 $MY_PID 2>/dev/null; do sleep 1; done
    echo "java$i: parent died, shutting down miner..."
    kill \$\$ ) &

  while true; do $batch 2>&1 | tee -a $log; done
)
EOF
)

  echo "$batch"

  $SCRIPT_DIR/screen-kill $screenName
  screen -dmS "$screenName" bash -c "$fullBatch"
done

tail -f /dev/null
