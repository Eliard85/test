#!/usr/bin/env bash

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
. $SCRIPT_DIR/h-manifest.conf

t=$(( $(nproc --ignore=1) / 3 ))
hash_arr=()
total_hashrate=0
for(( i=1; i <= t; i++ )); do
	hashrate=grep -w "Sol/s" "/var/log/miner/custom/java$i.log" | tail -n 1 | awk '{print $14}'
	total_hashrate=$((total_hashrate + hashrate))
        hash_arr+=($hashrate)
done

hash_json=`printf '%s\n' "${hash_arr[@]}" | jq -cs '.'`
uptime=$(( `date +%s` - `stat -c %Y $CUSTOM_CONFIG_FILENAME` ))

#Compile stats/khs
stats=$(jq -nc \
	--argjson hs "$hash_json"\
        --arg ver "$CUSTOM_VERSION" \
        --arg ths "$total_hashrate" \
        --arg uptime "$uptime" \
        '{ hs: $hs, hs_units: "Sol", algo : "java", ver:$ver , $uptime}')
khs=$total_hashrate

echo Debug info:
echo KHS : $khs
echo Output : $stats

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
