#!/usr/bin/env bash

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
. $SCRIPT_DIR/h-manifest.conf

algo=qhash
gpuCount=`gpu-detect NVIDIA`
uptime=
API_TIMEOUT=2
busid_json='[]'
fan_json='[]'
temp_json='[]'

declare -a hr_data=( )

for (( i=0; i < gpuCount; i++ )); do
  hr_data+=(0)
done

gpu_stats=$(< $GPU_STATS_JSON)
readarray -t gpu_stats < <( jq --slurp -r -c '.[] | .brand, .temp, .fan, .busids | join(" ")' $GPU_STATS_JSON 2>/dev/null)
brands=(${gpu_stats[0]})
temps=(${gpu_stats[1]})
fans=(${gpu_stats[2]})
busids=(${gpu_stats[3]})
gpuCountFromStatsJson=${#brands[@]}

fan_arr=()
temp_arr=()

for (( i=0; i < $gpuCountFromStatsJson; i++ )); do
  brand=${brands[$i]}

  if [[ ${brands[$i]} != 'cpu' ]]; then
    fan_arr+=(${fans[i]})
    temp_arr+=(${temps[i]})
  fi
done
[[ ${brands[0]} == 'cpu' ]] && internalCpuShift=1 || internalCpuShift=0

busidRawJson='[]'
for (( i=0; i < $gpuCount; i++ )); do
  y=`echo "$i + $internalCpuShift" | bc`
  busid=${busids[$y]}
  b=`echo $busid | awk -F ':' '{print $1}'`
  busidRawJson=$(jq ". += [\"$b\"]" <<< "$busidRawJson")
  fan_json=$(jq ". += [\"${fans[$y]}\"]" <<< "$fan_json")
  temp_json=$(jq ". += [\"${temps[$y]}\"]" <<< "$temp_json")

  apiPort="4444$i"
  stats_template=`echo "summary" | nc -w $API_TIMEOUT localhost $apiPort | tr -d '\0'`
  [[ -z $uptime ]] && uptime=`echo -e $stats_template | sed -e 's/;/\n/g; s/.*UPTIME=\([0-9]*\)\n.*/\1/'`

  rawHr=$(echo "$stats_template" | grep -oP '(^|;)HS=\K[^;]*')
  if [[ $rawHr ]]; then
      hr=`echo "scale=2; $rawHr / 1000" | bc -l`
      hr_data[$i]=$hr
  fi
done

for (( i=0; i < `echo $busidRawJson | jq 'length'`; i++ )); do
  busidHex=`echo $busidRawJson | jq -r ".[$i]"  | tr '[:lower:]' '[:upper:]'`
  [[ ${busidHex:0:1} == 0 ]] && busidHex=${busidHex:1:2}

  busidDecimal=`echo "ibase=16; $busidHex" | bc`

  busid_json=`jq ". + [\"$busidDecimal\"]" <<< "$busid_json"`
done

hr_json=$(printf '%s\n' "${hr_data[@]}" | jq -R . | jq -s .)

totalHr=0
for hr in "${hr_data[@]}"; do
  totalHr=$(echo "$totalHr + $hr" | bc)
done
totalKhs=`echo "scale=0; $totalHr / 1000" | bc -l`

  #Compile stats/khs
  stats=$(jq -nc \
  --arg algo "$algo" \
  --arg ver "$CUSTOM_VERSION" \
  --arg uptime "$uptime" \
  --argjson hs "$hr_json" \
  --arg hs_units "khs" \
  --arg ths $totalKhs \
  --argjson bus_numbers "$busid_json" \
  --argjson fan "$fan_json" \
  --argjson temp "$temp_json" \
      '{ $hs, $ths, $hs_units, $algo, $ver, $uptime, $bus_numbers, $fan, $temp}')

khs=$totalHr

#echo Debug info:
echo Log file : $CUSTOM_LOG_BASENAME.log
echo Time since last log entry : $diffTime
#echo Raw stats : $stats_raw
echo KHS : $khs
echo Output : $stats

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
