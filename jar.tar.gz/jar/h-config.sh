#!/usr/bin/env bash

echo "WORKER_NAME =             $WORKER_NAME"
echo "CUSTOM_TEMPLATE =         $CUSTOM_TEMPLATE"
echo "CUSTOM_URL =              $CUSTOM_URL"

conf=
conf+=" --url $CUSTOM_URL"
conf+=" -u $CUSTOM_TEMPLATE"

echo -e "$conf" > $CUSTOM_CONFIG_FILENAME
